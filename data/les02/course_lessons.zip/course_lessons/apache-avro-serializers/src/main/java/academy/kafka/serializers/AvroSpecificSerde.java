package academy.kafka.serializers;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

public class AvroSpecificSerde<T extends org.apache.avro.specific.SpecificRecord> implements Serde<T> {

    private final Serializer<T> serializer = new AvroSpecificSerializer<T>();
    private final Deserializer<T> deserializer = new AvroSpecificDeserializer<T>();

    @Override
    public Serializer<T> serializer() {
        return serializer;
    }

    @Override
    public Deserializer<T> deserializer() {
        return deserializer;
    }

    @Override
    public void configure(final java.util.Map<String, ?> serdeConfig, final boolean isSerdeForRecordKeys) {
        serializer.configure(serdeConfig, isSerdeForRecordKeys);
        deserializer.configure(serdeConfig, isSerdeForRecordKeys);
    }
}
