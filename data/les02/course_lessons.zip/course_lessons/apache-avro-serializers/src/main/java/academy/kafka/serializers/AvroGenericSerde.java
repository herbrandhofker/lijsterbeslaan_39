package academy.kafka.serializers;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import org.apache.avro.generic.GenericRecord;

public class AvroGenericSerde implements Serde<GenericRecord> {

    private final Serializer<GenericRecord> serializer= new AvroGenericSerializer();
    private final Deserializer<GenericRecord> deserializer= new AvroGenericDeserializer();

    @Override
    public Serializer<GenericRecord> serializer() {
        return serializer;
    }

    @Override
    public Deserializer<GenericRecord> deserializer() {
        return deserializer;
    }

    @Override
    public void configure(final java.util.Map<String, ?> serdeConfig, final boolean isSerdeForRecordKeys) {
      serializer.configure(serdeConfig, isSerdeForRecordKeys);
      deserializer.configure(serdeConfig, isSerdeForRecordKeys);
    }
}
