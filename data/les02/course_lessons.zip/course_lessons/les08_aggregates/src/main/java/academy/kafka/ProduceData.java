package academy.kafka;

public class ProduceData {

    public static void main(final String[] args) throws Exception {
        academy.kafka.GenerateData.generateSandbox(200);      
    }
}
